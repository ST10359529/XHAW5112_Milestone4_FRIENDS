package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast


class CourseListSixMonths : AppCompatActivity() {

    data class Course(val name: String, val price: Double)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_list_six_months)

        val intent = Intent("selectedCourses")

        val course1 = CourseListSixMonths.Course("First Aid", 1500.0)
        val course2 = CourseListSixMonths.Course("Sewing", 1500.0)
        val course3 = CourseListSixMonths.Course("Landscaping", 1500.0)
        val course4 = CourseListSixMonths.Course("Life Skills", 1500.0)



        val selectedCourses = mutableListOf<String>()

        var btnSubmit = findViewById<Button>(R.id.btnSubmit)
        var course1CheckBox = findViewById<CheckBox>(R.id.course1CheckBox)
        var course2CheckBox = findViewById<CheckBox>(R.id.course2CheckBox)
        var course3CheckBox = findViewById<CheckBox>(R.id.course3CheckBox)
        var course4CheckBox = findViewById<CheckBox>(R.id.course4CheckBox)
        var tvReadMore1 = findViewById<TextView>(R.id.tvReadMore1)
        var tvReadMore2 = findViewById<TextView>(R.id.tvReadMore2)
        var tvReadMore3 = findViewById<TextView>(R.id.tvReadMore3)
        var tvReadMore4 = findViewById<TextView>(R.id.tvReadMore4)

        val image = findViewById<ImageView>(R.id.imageView3)
        image.setImageResource(R.drawable.img)

        btnSubmit.setOnClickListener {

            if (selectedCourses.isEmpty()) {
                // No courses are selected; show an error message.
                Toast.makeText(this, "Please select at least one course.", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, Payment::class.java)
                intent.putStringArrayListExtra("selectedCourses", ArrayList(selectedCourses))
                startActivity(intent)
            }
        }

        //OnCheckedChangeListener for each CheckBox to keep track of selected courses
        course1CheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                selectedCourses.add(course1.name)
            } else {
                selectedCourses.remove(course1.name)
            }
        }

        course2CheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                selectedCourses.add(course2.name)
            } else {
                selectedCourses.remove(course2.name)
            }
        }

        course3CheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                selectedCourses.add(course3.name)
            } else {
                selectedCourses.remove(course3.name)
            }
        }

        course4CheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                selectedCourses.add(course4.name)
            } else {
                selectedCourses.remove(course4.name)
            }
        }

        tvReadMore1.setOnClickListener {
            val intent = Intent(this, FirstAid::class.java)
            startActivity(intent)
        }

        tvReadMore2.setOnClickListener {
            val intent = Intent(this, Sewing::class.java)
            startActivity(intent)
        }

        tvReadMore3.setOnClickListener {
            val intent = Intent(this, Landscaping::class.java)
            startActivity(intent)
        }

        tvReadMore4.setOnClickListener {
            val intent = Intent(this, LifeSkills::class.java)
            startActivity(intent)
        }

    }
}