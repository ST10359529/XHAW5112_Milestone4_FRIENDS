package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcelable
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class CourseListSixWeeks : AppCompatActivity() {

    data class Course(val name: String, val price: Double)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_list_six_weeks)

        val intent = Intent("selectedCourses")
        val course1 = Course("Child Minding", 750.0)
        val course2 = Course("Cooking", 750.0)
        val course3 = Course("Garden Maintenance", 750.0)

        // Initialize an empty list to store selected courses
        val selectedCourses = mutableListOf<String>()

        var btnSubmit = findViewById<Button>(R.id.btnSubmit)
        var course1CheckBox = findViewById<CheckBox>(R.id.course1CheckBox)
        var course2CheckBox = findViewById<CheckBox>(R.id.course2CheckBox)
        var course3CheckBox = findViewById<CheckBox>(R.id.course3CheckBox)
        var tvReadMore1 = findViewById<TextView>(R.id.tvReadMore1)
        var tvReadMore2 = findViewById<TextView>(R.id.tvReadMore2)
        var tvReadMore3 = findViewById<TextView>(R.id.tvReadMore3)

        val image = findViewById<ImageView>(R.id.imageView3)
        image.setImageResource(R.drawable.img)

        btnSubmit.setOnClickListener {

            if (selectedCourses.isEmpty()) {
                // No courses are selected; show an error message.
                Toast.makeText(this, "Please select at least one course.", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, Payment::class.java)
                intent.putStringArrayListExtra("selectedCourses", ArrayList(selectedCourses))
                startActivity(intent)
            }
        }

        //OnCheckedChangeListener for each CheckBox to keep track of selected courses
        course1CheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                selectedCourses.add(course1.name)
            } else {
                selectedCourses.remove(course1.name)
            }
        }


        course2CheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                selectedCourses.add(course2.name)
            } else {
                selectedCourses.remove(course2.name)
            }
        }

        course3CheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                selectedCourses.add(course3.name)
            } else {
                selectedCourses.remove(course3.name)
            }
        }

        tvReadMore1.setOnClickListener {
            val intent = Intent(this, ChildMinding::class.java)
            startActivity(intent)
        }

        tvReadMore2.setOnClickListener {
            val intent = Intent(this, Cooking::class.java)
            startActivity(intent)
        }

        tvReadMore3.setOnClickListener {
            val intent = Intent(this, GardenMaintenance::class.java)
            startActivity(intent)
        }
    }
}