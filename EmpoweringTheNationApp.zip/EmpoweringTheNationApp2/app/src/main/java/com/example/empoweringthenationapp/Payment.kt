package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import models.Course

class Payment : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        val intent = Intent("selectedCourses")

        val selectedCourses = intent.getSerializableExtra("selectedCourses") as? ArrayList<Course>

        val totalPrice = selectedCourses?.sumByDouble { it.price } ?: 0.0
        val discountPercentage = when (selectedCourses?.size ?: 0) {
            1 -> 0.00
            2 -> 0.05
            3 -> 0.1
            else -> 0.15
        }

        val discountAmount = totalPrice * discountPercentage

        val vat = 0.15 // 15% VAT
        val vatAmount = totalPrice * vat

        val finalTotal = totalPrice - discountAmount + vatAmount

        val tvDiscount = findViewById<TextView>(R.id.tvDiscount)
        tvDiscount.text = "Discount: ${String.format("%.2f%%", discountPercentage * 100)}"

        val formattedFinalTotal = String.format("%.2f", finalTotal)
        val tvTotal = findViewById<TextView>(R.id.tvTotal)
        tvTotal.text = "Total (with VAT and discount): $formattedFinalTotal"

        var btnNext = findViewById<Button>(R.id.btnNext)
        btnNext.setOnClickListener {
            val intent = Intent(this, ContactConsultant::class.java)
            startActivity(intent)
        }

    }
}