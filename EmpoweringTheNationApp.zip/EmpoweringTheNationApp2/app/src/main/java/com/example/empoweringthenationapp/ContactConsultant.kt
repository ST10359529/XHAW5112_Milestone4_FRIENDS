package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class ContactConsultant : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_consultant)

        var btnSubmit = findViewById<Button>(R.id.btnSubmit)
        var edtName = findViewById<EditText>(R.id.edtName)
        val edtEmail = findViewById<EditText>(R.id.edtEmail)
        var edtCell = findViewById<EditText>(R.id.edtCell)

        var image = findViewById<ImageView>(R.id.imageView4)
        image.setImageResource(R.drawable.img)

        btnSubmit.setOnClickListener {
            val name = edtName.text.toString()
            val email = edtEmail.text.toString()
            val cellphone = edtCell.text.toString()

            if (name.isEmpty() || email.isEmpty() || cellphone.isEmpty()) {
                // Display an error message using the TextInputLayout
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Request successfully sent.", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, ContactUs::class.java)
                startActivity(intent)
            }
        }

        var tvSkip = findViewById<TextView>(R.id.tvSkip)
        tvSkip.setOnClickListener {
            val intent = Intent(this, ContactUs::class.java)
            startActivity(intent)
        }

    }
}