package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class ChildMinding : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_child_minding)

        val image = findViewById<ImageView>(R.id.imageView7)
        image.setImageResource(R.drawable.close)

        image.setOnClickListener {
            val intent = Intent(this, CourseListSixWeeks::class.java)
            startActivity(intent)
        }
    }
}